"use client"

import RoyaltyManager from "../src/app/components/RoyaltyManager"

export default function SyntheticV0PageForDeployment() {
  return <RoyaltyManager />
}